<?php

class Monetha_Gateway_Const_Resource extends Mage_Core_Helper_Abstract
{
    const ORDER = 'order';
}
