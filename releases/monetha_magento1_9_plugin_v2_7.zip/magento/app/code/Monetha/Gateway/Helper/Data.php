<?php
class Monetha_Gateway_Helper_Data extends Mage_Core_Helper_Abstract
{

}