<?php

class Monetha_Gateway_Const_ApiType extends Mage_Core_Helper_Abstract
{
    const PROD = 'https://api.monetha.io/mth-gateway/';
    const TEST = 'https://api-sandbox.monetha.io/mth-gateway/';
}
